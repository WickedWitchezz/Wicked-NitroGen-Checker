# Discord Nitro Generator & Checker

## Presentation 📖
**Discord Nitro Generator & Checker** is a simple, efficace and fully configurable Discord Nitro generator.  
It supports advanced generation producing more than 100,000 links per minute

It will basically generate random codes and test them through Discord's API, and let you know where there's a hit.

## Installation 💾

- Make sure Python is installed
- To run type `python main.py`
- Select the number of links you want to generate

## Support 🖐
In case of bug just add me **Alive#1100**
